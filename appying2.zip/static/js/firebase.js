var config = {
  apiKey: "AIzaSyC-FWKPBQJMEn6Yj5hIGXiSWrVXQbFh85A",
  authDomain: "math-adventure.firebaseapp.com",
  databaseURL: "https://math-adventure.firebaseio.com",
  projectId: "math-adventure",
  storageBucket: "math-adventure.appspot.com",
  messagingSenderId: "802434340530"
  };
  firebase.initializeApp(config);